#pragma once


class CDS_DIALOG_UTILITY_SEARCH_INFO
{
public:
	CString  sDIR_ROOT;
	CString	 sFILE_EXT;

	CString  sFILE_NAME;
	CString  sFILE_PATH;
};
